from django.apps import AppConfig


class GestionConfig(AppConfig):
    name = 'gestion'
