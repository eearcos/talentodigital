from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import EventoForm, ParticipanteForm

def registro_view(request):
    if request.method == 'POST':
        evento_form = EventoForm(request.POST, prefix='evento')
        participante_form = ParticipanteForm(request.POST, prefix='participante')

        if evento_form.is_valid() and participante_form.is_valid():
            evento = evento_form.save()
            
            participante = participante_form.save(commit=False)
            participante.evento = evento
            participante.save()

            messages.success(request, f"¡Éxito! Evento '{evento.nombre}' registrado correctamente.")
            return redirect('registro')
            messages.error(request, "Hay errores en el formulario. Revisa los campos en rojo.")

    else:
        evento_form = EventoForm(prefix='evento')
        participante_form = ParticipanteForm(prefix='participante')

    return render(request, 'core/registro.html', {
        'evento_form': evento_form,
        'participante_form': participante_form
    })