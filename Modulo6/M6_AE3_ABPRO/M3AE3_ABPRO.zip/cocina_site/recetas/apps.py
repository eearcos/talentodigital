from django.apps import AppConfig


class RecetasConfig(AppConfig):
    name = 'recetas'
