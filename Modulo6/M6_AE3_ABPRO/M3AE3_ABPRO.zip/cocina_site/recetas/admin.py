from django.contrib import admin
from .models import Receta

admin.site.register(Receta)